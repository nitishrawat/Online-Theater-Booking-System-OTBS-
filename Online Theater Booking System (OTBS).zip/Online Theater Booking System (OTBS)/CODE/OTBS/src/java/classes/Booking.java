/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.sql.Time;
import java.sql.Date;
import java.sql.*;
import java.io.*;

/**
 *
 * @author nitish
 */
public class Booking {

    int booking_Id;
    String booking_Type;
    int show_Id;
    int user_Id;
    String booking_Class;
    int booking_Seats;
    int fare;
    String booking_Status;
    String booking_Date;
    String booking_Time;

    public static void cancelBooking(String Booking_Id) {
        String cancelBookingQuery = "DELETE FROM Booking WHERE Booking_Id='" + Booking_Id + "'";
        String updateBookingSeatQuery = "UPDATE Booking_Seats  SET Availability='available' where Booking_No='" + Booking_Id + "'";
        Connection con = null;
        Statement st = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/otbs", "root", "root");
            st = con.createStatement();

            st.executeUpdate(cancelBookingQuery);
            Statement st1 = con.createStatement();
            st1.executeUpdate(updateBookingSeatQuery);


            st.close();
            con.close();


        } catch (Exception e) {
            System.out.println("Catching Exception");
            System.out.println(e);

        }
    }

    public int getBooking_Id() {
        return this.booking_Id;
    }

    public int getFare() {
        return this.fare;
    }

    public String getBooking_Status() {
        return this.booking_Status;
    }

    public String getAllotedSeatNo() {
        String SeatNo = "";
        Connection con = null;
        Statement st = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/otbs", "root", "root");
            st = con.createStatement();
            ResultSet rs = st.executeQuery("select Seat_No from Booking_Seats where Booking_No='" + this.booking_Id + "'");
            while (rs.next()) {
                SeatNo = SeatNo + rs.getString(1) + ",";
            }

            st.close();
            con.close();


        } catch (Exception e) {
            System.out.println("Catching Exception");
            System.out.println(e);

        }
        return SeatNo;
    }

    public Booking(String Show_Id, String User_Id, String Booking_Type, String Booking_Class, int Booking_Seats) {

        Connection con = null;
        Statement st = null;
        int result_count = 0;
        int Booking_Id = -1;
        int Seat_Fare = 0;
        String Booking_Date = "2011-08-25";
        String Booking_Time = "16:00:00";
        String Fare_query = null;
        int Total_Fare = 0;
        String Booking_Status = null;

        int Seats_Available = 0;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/otbs", "root", "root");
            st = con.createStatement();
            Fare_query = "SELECT Fare FROM Theater_Details where Class='" + Booking_Class + "'";
            Statement st1 = con.createStatement();
            ResultSet FareResult = st1.executeQuery(Fare_query);
            if (FareResult.next()) {
                Seat_Fare = FareResult.getInt(1);
            }
            Total_Fare = Seat_Fare * Booking_Seats;

            String Booking_Seat_Available_query = "SELECT count(*) seat_available FROM Booking_Seats where Show_Id='" + Show_Id + "' AND Class='" + Booking_Class + "' AND Availability='available'";
            ResultSet BookingSeatsResult = st1.executeQuery(Booking_Seat_Available_query);

            if (BookingSeatsResult.next()) {
                Seats_Available = BookingSeatsResult.getInt(1);
            }
            if (Seats_Available > Booking_Seats) {
                Booking_Status = "booked";
            } else {
                Booking_Status = "waiting";
                if (!Booking_Class.equals("Balcony")) {
                    this.booking_Id = -1;
                    return;
                }
            }

            String query = "INSERT INTO Booking(Booking_Type,Show_Id,User_Id,Class,No_Of_Seats,Total_Fare,Booking_Status,Booking_Date,Booking_Time) "
                    + "VALUES('" + Booking_Type + "','" + Show_Id + "','" + User_Id + "','" + Booking_Class + "','" + Booking_Seats + "','" + Total_Fare + "','" + Booking_Status + "','" + Booking_Date + "','" + Booking_Time + "')";
            result_count = st.executeUpdate(query);
            if (result_count == 0) {
                System.out.println("Inserting Booking record failed.");
            }
            System.out.println("Booking Insertion Result count = " + result_count);
            Statement st4 = con.createStatement();
            ResultSet Booking_Id_Set = st4.executeQuery("SELECT Booking_Id FROM Booking where Show_Id='"
                    + Show_Id + "' AND Booking_Type='" + Booking_Type + "' AND Class='" + Booking_Class + "' AND No_Of_Seats='" + Booking_Seats + "' order by Booking_Id desc");
            if (Booking_Id_Set.next()) {
                Booking_Id = Booking_Id_Set.getInt("Booking_Id");
            }
            System.out.println("Booking_ID generated is " + Booking_Id);
            this.booking_Id = Booking_Id;
            this.booking_Type = Booking_Type;
            this.show_Id = Integer.parseInt(Show_Id);
            this.user_Id = Integer.parseInt(User_Id);
            this.booking_Class = Booking_Class;
            this.booking_Seats = Booking_Seats;
            this.fare = Total_Fare;
            this.booking_Status = Booking_Status;
            this.booking_Date = Booking_Date;
            this.booking_Time = Booking_Time;

            if (Booking_Status.equals("booked")) {
                for (int i = 0; i < Booking_Seats; i++) {
                    int Allot_Booking_Seat_Id = -1;
                    String Allot_Booking_Seat_Id_Query = "SELECT min(Booking_Seats_Id) FROM Booking_Seats where Show_Id='"
                            + Show_Id + "' AND Class='" + Booking_Class + "' AND Availability='available' ";
                    Statement st2 = con.createStatement();
                    ResultSet Allot_Id_Result = st2.executeQuery(Allot_Booking_Seat_Id_Query);
                    if (Allot_Id_Result.next()) {
                        Allot_Booking_Seat_Id = Allot_Id_Result.getInt(1);
                    }
                    String Booking_Seat_Update_query = "UPDATE Booking_Seats SET Availability='booked' ,Booking_No='" + Booking_Id + "' where Booking_Seats_Id='" + Allot_Booking_Seat_Id + "'";
                    Statement st3 = con.createStatement();
                    int c = st3.executeUpdate(Booking_Seat_Update_query);
                    if (c == 0) {
                        System.out.println("Seat allotment Failed");
                    }

                }
            }


            System.out.println("All classes added. While loop completed.");

            st.close();
            con.close();


        } catch (Exception e) {
            System.out.println("Catching Exception");
            System.out.println(e);

        }


    }
}
