/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.sql.Date;
import java.sql.Time;

import java.sql.*;
import java.io.*;
import java.util.*;

/**
 *
 * @author nitish
 */
public class Show {

    String show_Id;
    String show_Name;
    Time show_Time;
    Date show_Date;
    String total_Seats;

    public static String selectShowId(String Show_Name, String Show_Date, String Show_Time) {
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        Show s = new Show();
        String storedShowId = "-1";
        String query = "SELECT Show_Id FROM `Show`  where Show_Name='" + Show_Name
                + "' AND Show_Date='" + Show_Date + "' AND Show_Time='" + Show_Time + "'";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/otbs", "root", "root");
            st = con.createStatement();
            rs = st.executeQuery(query);
            if (rs.next()) {
                storedShowId = rs.getString("Show_Id");
            }
            st.close();
            con.close();
            return storedShowId;
        } catch (Exception e) {
            System.out.println(e);
        }
        return storedShowId;
    }

    public int insertShow(String Show_Name, String Show_Date, String Show_Time) {

        Connection con = null;
        Statement st = null;
        int result_count = 0;
        int Show_Id = 0;
        ResultSet ClassResult = null;
        String Booking_Seat_Insert_query = null;
        String Class_query = null;
        String query = "INSERT INTO `Show`(Show_Name,Show_Date,Show_Time) VALUES('"
                + Show_Name + "','" + Show_Date + "','" + Show_Time + "')";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/otbs", "root", "root");
            st = con.createStatement();
            result_count = st.executeUpdate(query);
            System.out.println("Result count = " + result_count);

            ResultSet Show_Id_Set = st.executeQuery("SELECT Show_Id FROM `Show` where Show_Name='"
                    + Show_Name + "' AND Show_Date='" + Show_Date + "' AND Show_Time='" + Show_Time + "'");
            if (Show_Id_Set.next()) {
                Show_Id = Show_Id_Set.getInt("Show_Id");
            }
            System.out.println("Show_ID generated is " + Show_Id);
            Class_query = "select distinct Class,No_Of_Seats from Theater_Details";
            Statement st1 = con.createStatement();
            ClassResult = st1.executeQuery(Class_query);
            /*       Array ClassArray = ClassResult.getArray("Class");
            /*          ArrayList list = new ArrayList(ClassArray);
            Set m = new 
             */ while (ClassResult.next()) {
                System.out.println("Adding Seats for class for a show");
                int no_Of_Seats_in_Class = ClassResult.getInt("No_Of_Seats");
                String class_Name = ClassResult.getString("Class");
                System.out.println("Class = " + class_Name);
                for (int i = 1; i <= no_Of_Seats_in_Class; i++) {

                    Booking_Seat_Insert_query = "INSERT INTO Booking_Seats(Show_Id,Class,Seat_No,Availability) VALUES('"
                            + String.valueOf(Show_Id) + "','" + class_Name + "','" + String.valueOf(i) + "','available')";
                    System.out.println(Booking_Seat_Insert_query);
                    int c = st.executeUpdate(Booking_Seat_Insert_query);
                    if (c == 0) {
                        return 0;
                    }


                }
                System.out.println("Class added. For loop over");


            }

            System.out.println("All classes added. While loop completed.");

            st.close();
            con.close();


        } catch (Exception e) {
            System.out.println("Catching Exception");
            System.out.println(e);

        }
        return result_count;

    }

    public int checkShow(String Show_Name) {
        int flag = 0;
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        String query = "SELECT Show_Name FROM `Show` where Show_Name='" + Show_Name + "'";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/otbs", "root", "root");
            st = con.createStatement();
            rs = st.executeQuery(query);
            if (rs.next()) {
                String storedShow = rs.getString("Show_Name");
                if (storedShow.matches(Show_Name)) {
                    flag = 1;
                } else {
                    flag = 0;
                }

            }
            st.close();
            con.close();
            return flag;

        } catch (Exception e) {
            System.out.println(e);
        }
        return flag;
    }
}
