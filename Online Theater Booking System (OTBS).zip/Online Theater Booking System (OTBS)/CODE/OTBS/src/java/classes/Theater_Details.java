/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.sql.*;
import java.io.*;
import java.util.*;

/**
 *
 * @author nitish
 */
public class Theater_Details {

    String seat_class;
    int fare;
    int no_of_seats;
    int max_seats_allowed;

    public int getFarebyClass(String seat_class) {
        Theater_Details td = new Theater_Details();
       
        if (getTheaterDetails(seat_class) == 1) {
            return this.fare;
        }
        return 0;
    }
    public int getNoSeatsbyClass(String seat_class) {
        Theater_Details td = new Theater_Details();
       
        if (getTheaterDetails(seat_class) == 1) {
            return this.no_of_seats;
        }
        return 0;
    }
    
    
    
  public int getMaxSeatsbyClass(String seat_class) {
        Theater_Details td = new Theater_Details();
       
        if (getTheaterDetails(seat_class) == 1) {
            return this.max_seats_allowed;
        }
        return 0;
    }
    private int getTheaterDetails(String seat_class) {
        int flag = 0;
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        String query = "SELECT Class,Fare,No_Of_Seats,Max_Seats_Allowed FROM Theater_Details where Class='" + seat_class + "'";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/otbs", "root", "root");
            st = con.createStatement();
            rs = st.executeQuery(query);
            if (rs.next()) {
                this.seat_class = rs.getString("Class");
                this.fare = rs.getInt("Fare");
                this.no_of_seats = rs.getInt("No_Of_Seats");
                this.max_seats_allowed = rs.getInt("Max_Seats_Allowed");
                if (rs.getString("Class").equals("")) {
                    flag = 0;
                } else {
                    flag = 1;
                }

            }
            st.close();
            con.close();
            return flag;

        } catch (Exception e) {
            System.out.println(e);
        }
        return flag;
    }

    public Theater_Details() {
        seat_class = "";
        fare = 0;
        no_of_seats = 0;
        max_seats_allowed = 0;
    }

    public int checkClass(String theater_Class) {
        int flag = 0;
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        String query = "SELECT Class FROM Theater_Details where Class='" + theater_Class + "'";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/otbs", "root", "root");
            st = con.createStatement();
            rs = st.executeQuery(query);
            if (rs.next()) {
                String storedClass = rs.getString("Class");
                if (storedClass.matches(theater_Class)) {
                    flag = 1;
                } else {
                    flag = 0;
                }

            }
            st.close();
            con.close();
            return flag;

        } catch (Exception e) {
            System.out.println(e);
        }
        return flag;
    }
      public int insertClass(String theater_class, String fare, String no_Of_Seats, String max_Seats_Allowed) {

        Connection con = null;
        Statement st = null;
        int result_count = 0;
        String query = "INSERT INTO Theater_Details(Class,Fare,No_Of_Seats,Max_Seats_Allowed) VALUES('"
                + theater_class + "','" + fare + "','" + no_Of_Seats + "','" + max_Seats_Allowed + "')";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/otbs", "root", "root");
            st = con.createStatement();
            result_count = st.executeUpdate(query);
            st.close();
            con.close();


        } catch (Exception e) {
            System.out.println(e);
        }
        return result_count;

    }
    //td.updateClass(theater_class,fare,no_Of_Seats,max_Seats_Allowed);
public int updateClass(String theater_class, String fare, String no_Of_Seats, String max_Seats_Allowed) {

        Connection con = null;
        Statement st = null;
        int result_count = 0;
        String query = "UPDATE Theater_Details SET Fare='"+fare
                +"' ,No_Of_Seats='"+no_Of_Seats+"', Max_Seats_Allowed='"+max_Seats_Allowed+"' where Class='"+theater_class+"'";
       try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/otbs", "root", "root");
            st = con.createStatement();
            result_count = st.executeUpdate(query);
            st.close();
            con.close();


        } catch (Exception e) {
            System.out.println(e);
        }
        return result_count;

    }
  
}
